<?php

// enter the DB password below
$db_password = "PNk4OzPjeN8=";

// decrypt the password with the known symmetric key
$plain_password = openssl_decrypt($db_password, "aes-256-ctr", "MySymmetricKey");

// display the results
echo "Encrypted: $db_password; decrypted: $plain_password<p/>\n";

?>

