<?php

$DICTIONARY = "words.txt";

// enter the DB hash below
$db_password = "56965e2a1a995c74da500088947af11dfa27951cc350d0b97d0633075969c31b";

// grab the dictionary words
$words = file($DICTIONARY, FILE_IGNORE_NEW_LINES);

// hash each dictionary word and compare
foreach ($words as $password)
{
		echo "Trying: $password<br/>\n";
		if (hash("sha256", $password) == $db_password)
		{
				// we found it!
				echo "**SUCCESS!<p/>\n";
				break;
		}
}

?>

