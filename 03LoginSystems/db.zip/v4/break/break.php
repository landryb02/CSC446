<?php

$DICTIONARY = "words.txt";

// enter the DB hash below
$db_password = "2962a362a60931fc0692f3ce862f6c2f499e84e17834a5f189336b1531474a4a";
// enter the DB salt below
$db_salt = "9b310800cc59c66758b35640d4c0a75f";

// grab the dictionary words
$words = file($DICTIONARY, FILE_IGNORE_NEW_LINES);

// hash each dictionary word and compare
foreach ($words as $password)
{
		echo "Trying: $password<br/>\n";
		if (hash("sha256", hex2bin($db_salt) . $password) == $db_password)
		{
				// we found it!
				echo "**SUCCESS!<p/>\n";
				break;
		}
}

?>

