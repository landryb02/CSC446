#!/usr/bin/php

<?php

// initialize the database
$db = new SQLite3("test.db");

// create the users table
$sql = "DROP TABLE `users`";
$db->exec($sql);
$sql = "CREATE TABLE IF NOT EXISTS `users` (`username` varchar(50) NOT NULL,`password` varchar(255) NOT NULL)";
$db->exec($sql);

// insert data
$db->exec("INSERT INTO `users` VALUES ('joe','pa55w0rd')");
$db->exec("INSERT INTO `users` VALUES ('kevin','andall')");
$db->exec("INSERT INTO `users` VALUES ('mike','superiority')");

?>
