#!/usr/bin/php

<?php

// initialize the database
$db = new SQLite3("test.db");

// query the database
$q = $db->query("SELECT * FROM `users`");
// display the returned rows
while ($r = $q->fetchArray())
    echo $r['username'] . " > " . $r['password'] . "\n";

?>
